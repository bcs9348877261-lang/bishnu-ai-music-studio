BISHNU AI MUSIC STUDIO — MOBILE EDITION

यह एक मोबाइल-फ्रेंडली PWA starter app है। इसे Android Chrome में HTTPS hosting से खोलकर Install / Add to Home screen किया जा सकता है।

महत्वपूर्ण:
- App में humming रिकॉर्ड करना, recording डाउनलोड करना, lyrics/style तैयार करना, AI prompt copy करना और AI से डाउनलोड हुए गाने को सुनना/फिर डाउनलोड करना शामिल है।
- पूरा गाना MusGen Hum-to-Song या Suno जैसे बाहरी AI generator में बनता है। यह ZIP अपने-आप AI सेवा में audio upload नहीं करती; आपको AI website पर upload करना होगा।
- MusGen Hum-to-Song की reference audio सीमा 30 सेकंड है और एक generation में 3 credits लगते हैं। Free credits जब उपलब्ध हों तभी मुफ्त generation संभव है। Free downloads के commercial rights की गारंटी नहीं है।
- Suno free usage और downloads/rights की सीमाएँ उसके मौजूदा plan पर निर्भर करती हैं।
- ऐप में अभी असली DJ multitrack mixer, voice cloning या AI inference engine नहीं है। इनको जोड़ने के लिए अलग audio engine और licensed AI API/model आवश्यक होगा।

मोबाइल से चलाने का आसान तरीका:
1. ZIP को फोन में डाउनलोड करें और Files app से Extract करें।
2. index.html को Chrome में खोलने की कोशिश करें। Local file से microphone permission हर फोन पर काम नहीं करती।
3. PWA install करने के लिए project को HTTPS पर host करना होगा (जैसे GitHub Pages)। GitHub mobile site पर repository बनाकर ये तीन फाइलें upload करें: index.html, manifest.webmanifest, sw.js; Settings > Pages से deploy करें।
4. Pages का HTTPS link Chrome में खोलें > ⋮ > Add to Home screen / Install app.
5. ऐप खोलें, microphone permission दें, 10–30 sec humming रिकॉर्ड करें और डाउनलोड करें।
6. MusGen Hum-to-Song खोलें, humming upload करें, lyrics/style भरें, generate करें और MP3 डाउनलोड करें।
7. तैयार MP3 को app के “AI से डाउनलोड किया हुआ गाना चुनें” में चुनें।

इस ऐप को बिना HTTPS hosting के installable PWA नहीं बनाया जा सकता। APK build करना भी अलग प्रक्रिया है; इस पैकेज में APK शामिल नहीं है।
